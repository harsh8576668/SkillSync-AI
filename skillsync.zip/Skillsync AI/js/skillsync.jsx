/* eslint-disable */
// ============================================================
//  SkillSync AI — Complete Application (skillsync.jsx)
//  White + Royal Blue Theme | Skill-Based Group Creation & Teammate Matching
//  Core Purpose: Create skill-based groups & connect students with complementary skills.
// ============================================================

const { useState, useEffect, useRef, useCallback } = React;

// ─── SAFE LOCALSTORAGE HELPERS ──────────────────────────────
const safeGetStorage = (key) => {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : null;
  } catch (e) {
    console.error(`Error reading ${key} from localStorage:`, e);
    return null;
  }
};

const safeSetStorage = (key, value) => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.error(`Error writing ${key} to localStorage:`, e);
  }
};

// ─── GITHUB UTILITIES ────────────────────────────────────────
function extractGitHubUsername(input) {
  if (!input) return "";
  let clean = input.trim();
  clean = clean.replace(/^https?:\/\//i, "");
  clean = clean.replace(/^(www\.)?github\.com\//i, "");
  clean = clean.split("/")[0].split("?")[0].trim();
  return clean;
}

function formatDateRelative(dateString) {
  if (!dateString) return "Recently updated";
  try {
    const d = new Date(dateString);
    if (isNaN(d.getTime())) return dateString;
    const diffMs = new Date() - d;
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    if (diffDays <= 0) return "Updated today";
    if (diffDays === 1) return "Updated yesterday";
    if (diffDays < 30) return `Updated ${diffDays} days ago`;
    if (diffDays < 365) return `Updated ${Math.floor(diffDays / 30)} months ago`;
    return `Updated on ${d.toLocaleDateString()}`;
  } catch (e) {
    return dateString;
  }
}

async function fetchGitHubProfile(username) {
  const cleanUser = extractGitHubUsername(username);
  if (!cleanUser) throw new Error("Please enter a valid GitHub username.");
  const res = await fetch(`https://api.github.com/users/${encodeURIComponent(cleanUser)}`);
  if (!res.ok) throw new Error("GitHub profile not found.");
  const data = await res.json();
  return {
    login: data.login,
    name: data.name || data.login,
    avatar_url: data.avatar_url,
    bio: data.bio || "",
    public_repos: data.public_repos || 0,
    followers: data.followers || 0,
    following: data.following || 0,
    html_url: data.html_url
  };
}

async function fetchGitHubRepos(username) {
  const cleanUser = extractGitHubUsername(username);
  if (!cleanUser) return [];
  const res = await fetch(`https://api.github.com/users/${encodeURIComponent(cleanUser)}/repos?sort=updated&per_page=50`);
  if (!res.ok) return [];
  const data = await res.json();
  return Array.isArray(data) ? data.map(r => ({
    id: r.id,
    name: r.name,
    description: r.description || "No description provided.",
    language: r.language || "Other",
    stargazers_count: r.stargazers_count || 0,
    forks_count: r.forks_count || 0,
    updated_at: r.updated_at,
    html_url: r.html_url
  })) : [];
}

// ─── SKILL MATCHING ALGORITHM ────────────────────────────────
function calculateSkillMatch(groupRequiredSkills = [], candidateUser = {}) {
  const reqSkills = groupRequiredSkills.map(s => s.toLowerCase());
  if (reqSkills.length === 0) {
    return { matchPercent: 85, matchReason: "Compatible skill set", matchingSkills: candidateUser.skills || [] };
  }

  const userSkills = (candidateUser.skills || []).map(s => s.toLowerCase());
  const secondarySkills = (candidateUser.secondarySkills || []).map(s => s.toLowerCase());
  const learningSkills = (candidateUser.learningSkills || []).map(s => s.toLowerCase());
  const interests = (candidateUser.interests || []).map(s => s.toLowerCase());

  const allUserSkills = [...userSkills, ...secondarySkills, ...learningSkills, ...interests];

  const exactMatches = reqSkills.filter(s => userSkills.includes(s));
  const partialMatches = reqSkills.filter(s => allUserSkills.includes(s));

  let score = 60;
  score += exactMatches.length * 20;
  score += (partialMatches.length - exactMatches.length) * 10;
  score = Math.min(98, Math.max(68, score));

  let matchReason = "Compatible collaborator";
  if (reqSkills.some(s => s.includes("ml") || s.includes("python") || s.includes("ai")) && userSkills.some(s => s.includes("ml") || s.includes("python") || s.includes("ai"))) {
    matchReason = "Strong ML / AI match";
  } else if (reqSkills.some(s => s.includes("react") || s.includes("web") || s.includes("frontend")) && userSkills.some(s => s.includes("react") || s.includes("web") || s.includes("frontend"))) {
    matchReason = "Strong Frontend match";
  } else if (reqSkills.some(s => s.includes("design") || s.includes("ui") || s.includes("figma")) && userSkills.some(s => s.includes("design") || s.includes("ui") || s.includes("figma"))) {
    matchReason = "Strong Design match";
  } else if (reqSkills.some(s => s.includes("node") || s.includes("java") || s.includes("backend")) && userSkills.some(s => s.includes("node") || s.includes("java") || s.includes("backend"))) {
    matchReason = "Strong Backend match";
  }

  const matchingSkillsTags = (candidateUser.skills || []).filter(s => reqSkills.includes(s.toLowerCase()));

  return {
    matchPercent: score,
    matchReason,
    matchingSkills: matchingSkillsTags.length > 0 ? matchingSkillsTags : (candidateUser.skills || []).slice(0, 3)
  };
}

// ─── REACT ERROR BOUNDARY ────────────────────────────────────
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }
  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }
  componentDidCatch(error, errorInfo) {
    console.error("SkillSync AI React Error Boundary:", error, errorInfo);
  }
  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
          <div className="bg-white p-8 rounded-2xl shadow-xl max-w-md text-center border border-slate-200">
            <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">⚠️</div>
            <h2 className="text-xl font-extrabold text-slate-900 mb-2">Something went wrong</h2>
            <p className="text-sm text-slate-600 mb-6">A component encountered a temporary rendering issue. Please reload to continue.</p>
            <button
              onClick={() => {
                this.setState({ hasError: false, error: null });
                window.location.reload();
              }}
              className="px-5 py-2.5 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 transition-colors text-sm shadow-sm"
            >
              Reload Application
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

// ─── CONSTANTS & CONFIG ──────────────────────────────────────
const COLLEGES = [
  "IIT Delhi","IIT Bombay","IIT Madras","NIT Trichy","VIT Vellore",
  "SRM University","BITS Pilani","IIM Ahmedabad","MIT Manipal",
  "Amity University","Anna University","Jadavpur University",
  "DTU Delhi","NSUT Delhi","Thapar University","Silver Oak University","Nirma University"
];

const SKILLS_LIST = [
  "AI/ML","Data Science","Python","Java","React","Node.js","UI/UX","Figma",
  "Machine Learning","Deep Learning","Web Development","App Development","Flutter",
  "Cybersecurity","Cloud","DevOps","Blockchain","C++","TypeScript","Next.js",
  "MongoDB","Docker","AWS","TensorFlow","PyTorch","NLP","Solidity"
];

const GROUP_TYPES = [
  "College Project", "Hackathon", "Startup", "Open Source", "Study Group", "Research"
];

const YEARS = ["1st Year", "2nd Year", "3rd Year", "4th Year", "Postgraduate", "PhD", "Alumni"];

const TEAM_SIZES = ["2 Members", "3 Members", "4 Members", "5 Members", "6+ Members"];

// Initial Real Skill Groups
const INITIAL_GROUPS = [
  {
    id: "grp_1",
    name: "AI Resume Screening Platform",
    description: "Building an AI-powered resume analysis and ATS scoring platform for student placement prep.",
    creator: { id: "usr_1", name: "Harsh Visodiya", college: "Silver Oak University" },
    requiredSkills: ["Python", "Machine Learning", "React", "UI/UX"],
    members: [
      { id: "usr_1", name: "Harsh Visodiya", role: "Leader & ML Engineer", skills: ["Python", "Machine Learning", "React"] },
      { id: "usr_2", name: "Rahul Sharma", role: "Frontend Dev", skills: ["React", "UI/UX", "Figma"] }
    ],
    maxMembers: 4,
    projectType: "Hackathon",
    visibility: "Public",
    createdAt: new Date().toISOString()
  },
  {
    id: "grp_2",
    name: "Full-Stack Campus Exchange",
    description: "Student marketplace and peer skill sharing web application.",
    creator: { id: "usr_3", name: "Meet Patel", college: "Ahmedabad University" },
    requiredSkills: ["React", "Node.js", "MongoDB", "TypeScript"],
    members: [
      { id: "usr_3", name: "Meet Patel", role: "Leader & Backend", skills: ["Node.js", "MongoDB", "Express"] },
      { id: "usr_4", name: "Priya Shah", role: "UI Designer", skills: ["UI/UX", "Figma", "CSS"] }
    ],
    maxMembers: 5,
    projectType: "Startup",
    visibility: "Public",
    createdAt: new Date().toISOString()
  },
  {
    id: "grp_3",
    name: "CyberSecurity CTF Squad",
    description: "National CTF competition team focusing on penetration testing and reverse engineering.",
    creator: { id: "usr_5", name: "Ishaan Bose", college: "Jadavpur University" },
    requiredSkills: ["Cybersecurity", "Python", "Linux", "C++"],
    members: [
      { id: "usr_5", name: "Ishaan Bose", role: "Leader & Security", skills: ["Cybersecurity", "Linux", "Python"] }
    ],
    maxMembers: 4,
    projectType: "College Project",
    visibility: "Public",
    createdAt: new Date().toISOString()
  },
  {
    id: "grp_4",
    name: "EdTech AI Tutor Open Source",
    description: "Personalized learning assistant for high school & college students.",
    creator: { id: "usr_6", name: "Ananya Roy", college: "Amity University" },
    requiredSkills: ["Python", "NLP", "Flutter", "UI/UX"],
    members: [
      { id: "usr_6", name: "Ananya Roy", role: "Product & ML", skills: ["Python", "NLP", "Data Science"] }
    ],
    maxMembers: 4,
    projectType: "Open Source",
    visibility: "Public",
    createdAt: new Date().toISOString()
  }
];

// Initial Real Students for Skill Matching
const INITIAL_STUDENTS = [
  {
    id: "usr_1",
    name: "Harsh Visodiya",
    email: "harsh@skillsync.edu",
    college: "Silver Oak University",
    year: "4th Year",
    domain: "AI/ML",
    skills: ["Python", "Machine Learning", "React", "MongoDB"],
    secondarySkills: ["FastAPI", "Node.js"],
    learningSkills: ["Deep Learning", "PyTorch"],
    interests: ["Hackathon", "Startup"],
    bio: "Computer science student specializing in ML pipelines and web apps.",
    githubUrl: "https://github.com/harshvisodiya"
  },
  {
    id: "usr_2",
    name: "Rahul Sharma",
    email: "rahul@nirma.edu",
    college: "Nirma University",
    year: "4th Year",
    domain: "Web Development",
    skills: ["React", "UI/UX", "Figma", "TypeScript"],
    secondarySkills: ["CSS", "Next.js"],
    learningSkills: ["Node.js"],
    interests: ["Startup", "College Project"],
    bio: "Frontend developer building modern, accessible user interfaces.",
    githubUrl: "https://github.com/rahulsharma"
  },
  {
    id: "usr_3",
    name: "Meet Patel",
    email: "meet@ahduni.edu",
    college: "Ahmedabad University",
    year: "3rd Year",
    domain: "Backend Development",
    skills: ["Node.js", "Express", "MongoDB", "Java"],
    secondarySkills: ["Docker", "REST API"],
    learningSkills: ["Kubernetes", "Go"],
    interests: ["Open Source", "Hackathon"],
    bio: "Backend developer interested in microservices and scalable infra.",
    githubUrl: "https://github.com/meetpatel"
  },
  {
    id: "usr_4",
    name: "Priya Shah",
    email: "priya@gtu.edu",
    college: "GTU Ahmedabad",
    year: "3rd Year",
    domain: "UI/UX Design",
    skills: ["UI/UX", "Figma", "CSS", "React"],
    secondarySkills: ["Prototyping", "Design Systems"],
    learningSkills: ["3D Animation", "Spline"],
    interests: ["Startup", "Design"],
    bio: "UI/UX designer who codes. Passionate about design systems.",
    githubUrl: "https://github.com/priyashah"
  },
  {
    id: "usr_6",
    name: "Ananya Roy",
    email: "ananya@amity.edu",
    college: "Amity University",
    year: "3rd Year",
    domain: "Data Science & NLP",
    skills: ["Python", "NLP", "Data Science", "PyTorch"],
    secondarySkills: ["Pandas", "Scikit-Learn"],
    learningSkills: ["LLM Fine-Tuning"],
    interests: ["Research", "Open Source"],
    bio: "Data scientist working on natural language processing models.",
    githubUrl: "https://github.com/ananyaroy"
  }
];

const getAvatarBg = (initials) => {
  const colors = [
    "bg-blue-600","bg-indigo-600","bg-violet-600","bg-sky-600",
    "bg-cyan-600","bg-teal-600","bg-blue-700","bg-indigo-700"
  ];
  const str = initials || "SS";
  const idx = (str.charCodeAt(0) + (str.charCodeAt(1) || 0)) % colors.length;
  return colors[idx];
};

const Toast = ({ message, type = "success", onClose }) => {
  useEffect(() => { const t = setTimeout(onClose, 3500); return () => clearTimeout(t); }, [onClose]);
  return (
    <div className={`toast-enter fixed bottom-6 right-6 z-[9999] flex items-center gap-3 px-5 py-3 rounded-xl shadow-xl text-white text-sm font-medium ${type === "success" ? "bg-blue-600" : type === "error" ? "bg-red-500" : "bg-slate-700"}`}>
      <span>{type === "success" ? "✓" : type === "error" ? "✕" : "ℹ"}</span>
      <span>{message}</span>
      <button onClick={onClose} className="ml-2 opacity-70 hover:opacity-100 text-lg">×</button>
    </div>
  );
};

// ─── NAVBAR ───────────────────────────────────────────────────
const Navbar = ({ page, setPage, user, onSignOut, onSignIn, pendingCount = 0 }) => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 10);
    window.addEventListener("scroll", fn);
    return () => window.removeEventListener("scroll", fn);
  }, []);

  const navLinks = user
    ? [
        { id: "dashboard", label: "Dashboard" },
        { id: "discover", label: "Discover Groups" },
        { id: "my-groups", label: `My Groups ${pendingCount > 0 ? `(${pendingCount})` : ''}` },
        { id: "teams", label: "All Skill Teams" },
        { id: "chat", label: "Messages" },
        { id: "swap", label: "Room Swap" },
      ]
    : [
        { id: "features", label: "Features" },
        { id: "how", label: "How It Works" },
        { id: "team", label: "Our Team" },
      ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 ${scrolled ? "bg-white shadow-md border-b border-slate-200" : "bg-white/90 backdrop-blur-md"} transition-all duration-200`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <button onClick={() => setPage(user ? "dashboard" : "landing")} className="flex items-center gap-2 group">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center shadow-sm group-hover:bg-blue-700 transition-colors">
              <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
              </svg>
            </div>
            <span className="font-bold text-lg text-slate-900">SkillSync<span className="text-blue-600"> AI</span></span>
          </button>

          {/* Desktop Links */}
          <div className="hidden md:flex items-center gap-1">
            {navLinks.map(l => (
              <button key={l.id} onClick={() => {
                if (["features","how","team"].includes(l.id)) {
                  setPage("landing");
                  setTimeout(() => document.getElementById(l.id)?.scrollIntoView({ behavior:"smooth" }), 100);
                } else setPage(l.id);
              }}
                className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-colors ${page === l.id ? "bg-blue-50 text-blue-600 font-semibold" : "text-slate-600 hover:text-slate-900 hover:bg-slate-50"}`}>
                {l.label}
              </button>
            ))}
          </div>

          {/* Auth / User */}
          <div className="flex items-center gap-3">
            {user ? (
              <div className="flex items-center gap-3">
                <button onClick={() => setPage("profile")} className="flex items-center gap-2 hover:bg-slate-50 px-3 py-1.5 rounded-lg transition-colors">
                  <div className={`w-8 h-8 rounded-full ${getAvatarBg(user.displayName?.substring(0,2).toUpperCase()||"U")} flex items-center justify-center text-white text-xs font-bold`}>
                    {user.displayName?.substring(0,2).toUpperCase()||"U"}
                  </div>
                  <span className="text-sm font-medium text-slate-700 hidden sm:block">{user.displayName?.split(" ")[0]}</span>
                </button>
                <button onClick={onSignOut} className="text-sm text-slate-500 hover:text-red-500 transition-colors hidden sm:block">Sign out</button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button onClick={() => onSignIn("signin")} className="text-sm font-medium text-slate-600 hover:text-slate-900 px-4 py-2 rounded-lg hover:bg-slate-50 transition-colors">Sign In</button>
                <button onClick={() => onSignIn("signup")} className="text-sm font-semibold bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors shadow-sm">Get Started Free</button>
              </div>
            )}
            <button className="md:hidden p-2 rounded-lg hover:bg-slate-50" onClick={() => setMenuOpen(!menuOpen)}>
              <svg className="w-5 h-5 text-slate-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d={menuOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"} />
              </svg>
            </button>
          </div>
        </div>
      </div>
      {menuOpen && (
        <div className="md:hidden border-t border-slate-100 bg-white py-3 px-4 space-y-1">
          {navLinks.map(l => (
            <button key={l.id} onClick={() => { setMenuOpen(false); setPage(l.id); }}
              className="w-full text-left px-4 py-2.5 rounded-lg text-sm text-slate-700 hover:bg-blue-50 hover:text-blue-600 font-medium">
              {l.label}
            </button>
          ))}
        </div>
      )}
    </nav>
  );
};

// ─── LANDING PAGE ──────────────────────────────────────────────
const LandingPage = ({ onSignIn }) => {
  return (
    <div className="min-h-screen bg-slate-50 pt-20 pb-16">
      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 pb-16 text-center">
        <span className="inline-block px-4 py-1.5 bg-blue-50 text-blue-700 rounded-full text-xs font-extrabold mb-6 border border-blue-100 shadow-xs">
          🚀 The Student Collaboration Platform
        </span>
        <h1 className="text-4xl sm:text-6xl font-black text-slate-900 tracking-tight max-w-4xl mx-auto leading-tight mb-6">
          Create Skill-Based Groups & Find <span className="text-blue-600">Complementary Teammates</span>
        </h1>
        <p className="text-slate-600 text-base sm:text-lg max-w-2xl mx-auto mb-8 leading-relaxed">
          Stop searching everywhere for project partners. SkillSync AI matches students based on complementary skills for hackathons, startups, college projects, and research.
        </p>

        <div className="flex flex-wrap justify-center gap-4">
          <button
            onClick={() => onSignIn("signup")}
            className="px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-base rounded-2xl transition-all shadow-lg hover:shadow-blue-500/25 flex items-center gap-2"
          >
            <span>+ Create Your Skill Group</span>
          </button>
          <button
            onClick={() => onSignIn("signin")}
            className="px-8 py-4 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 font-bold text-base rounded-2xl transition-all shadow-sm"
          >
            🔍 Find Teammates by Skills
          </button>
        </div>
      </div>

      {/* Core Features Section */}
      <div id="features" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-extrabold text-slate-900 mb-3">Designed Around Skill-Based Team Building</h2>
          <p className="text-slate-500 text-sm max-w-xl mx-auto">Everything you need to form high-impact project teams with students across universities.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-xs">
            <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center text-xl font-bold mb-5">🎯</div>
            <h3 className="text-lg font-extrabold text-slate-900 mb-2">Skill Group Creation</h3>
            <p className="text-xs text-slate-500 leading-relaxed">Define required team skills (Python, ML, React, UI/UX), project type, and team size to launch your project squad.</p>
          </div>

          <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-xs">
            <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center text-xl font-bold mb-5">⚡</div>
            <h3 className="text-lg font-extrabold text-slate-900 mb-2">Skill Match Algorithm</h3>
            <p className="text-xs text-slate-500 leading-relaxed">Automatically calculates match percentages (95% Match) and skill fit reasons ("Strong ML match") for every teammate candidate.</p>
          </div>

          <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-xs">
            <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center text-xl font-bold mb-5">👥</div>
            <h3 className="text-lg font-extrabold text-slate-900 mb-2">My Groups Workspace</h3>
            <p className="text-xs text-slate-500 leading-relaxed">Manage created teams, joined groups, real-time invitations, and peer join requests seamlessly in one dashboard.</p>
          </div>
        </div>
      </div>

      {/* How It Works Section */}
      <div id="how" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 bg-white border-y border-slate-200">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-extrabold text-slate-900 mb-3">How SkillSync AI Works</h2>
          <p className="text-slate-500 text-sm">Three simple steps to build your dream project team.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="text-center p-6">
            <div className="w-10 h-10 bg-blue-600 text-white rounded-full flex items-center justify-center font-extrabold mx-auto mb-4 text-sm">1</div>
            <h3 className="font-extrabold text-slate-900 text-base mb-2">Build Your Skill Profile</h3>
            <p className="text-xs text-slate-500 leading-relaxed">Add your primary skills, secondary skills, and learning goals to let teammates discover you.</p>
          </div>

          <div className="text-center p-6">
            <div className="w-10 h-10 bg-blue-600 text-white rounded-full flex items-center justify-center font-extrabold mx-auto mb-4 text-sm">2</div>
            <h3 className="font-extrabold text-slate-900 text-base mb-2">Create or Discover Groups</h3>
            <p className="text-xs text-slate-500 leading-relaxed">Post your project vision and required skills, or browse active student groups looking for your domain.</p>
          </div>

          <div className="text-center p-6">
            <div className="w-10 h-10 bg-blue-600 text-white rounded-full flex items-center justify-center font-extrabold mx-auto mb-4 text-sm">3</div>
            <h3 className="font-extrabold text-slate-900 text-base mb-2">Invite & Collaborate</h3>
            <p className="text-xs text-slate-500 leading-relaxed">Send real-time invitations to top-matched student candidates and start building together.</p>
          </div>
        </div>
      </div>

      {/* Our Team Section */}
      <div id="team" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-extrabold text-slate-900 mb-3">Built For Students, By Students</h2>
          <p className="text-slate-500 text-sm">Meet the creator behind SkillSync AI.</p>
        </div>

        <div className="max-w-sm mx-auto bg-white border border-slate-200 rounded-3xl p-8 text-center shadow-xs">
          <div className="w-20 h-20 bg-blue-600 rounded-full text-white font-extrabold text-2xl flex items-center justify-center mx-auto mb-4 shadow-md">HV</div>
          <h3 className="font-extrabold text-slate-900 text-lg">Harsh Visodiya</h3>
          <p className="text-blue-600 text-xs font-bold mb-2">Founder & Lead Developer</p>
          <p className="text-slate-500 text-xs leading-relaxed">Silver Oak University · Computer Science & AI Specialist.</p>
        </div>
      </div>
    </div>
  );
};

// ─── CREATE SKILL GROUP MODAL ────────────────────────────────
const CreateSkillGroupModal = ({ onClose, onCreateGroup }) => {
  const [form, setForm] = useState({
    name: "",
    description: "",
    requiredSkills: ["Python", "React"],
    maxMembers: "4",
    projectType: "Hackathon",
    visibility: "Public"
  });
  const [customSkill, setCustomSkill] = useState("");
  const [errors, setErrors] = useState({});

  const toggleSkill = (skill) => {
    setForm(p => ({
      ...p,
      requiredSkills: p.requiredSkills.includes(skill)
        ? p.requiredSkills.filter(s => s !== skill)
        : [...p.requiredSkills, skill]
    }));
  };

  const addCustomSkill = () => {
    if (customSkill.trim() && !form.requiredSkills.includes(customSkill.trim())) {
      setForm(p => ({ ...p, requiredSkills: [...p.requiredSkills, customSkill.trim()] }));
      setCustomSkill("");
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const errs = {};
    if (!form.name.trim()) errs.name = "Group name is required";
    if (!form.description.trim()) errs.description = "Project description is required";
    if (form.requiredSkills.length === 0) errs.skills = "Select at least one required skill";

    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }

    onCreateGroup({
      ...form,
      maxMembers: parseInt(form.maxMembers, 10) || 4
    });
  };

  return (
    <div className="fixed inset-0 z-[9000] flex items-center justify-center p-4" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-sm" />
      <div className="relative bg-white rounded-3xl shadow-2xl w-full max-w-xl max-h-[92vh] overflow-y-auto fade-up p-7 sm:p-8">
        <button onClick={onClose} className="absolute top-5 right-5 w-8 h-8 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-700 flex items-center justify-center font-bold">✕</button>
        
        <div className="flex items-center gap-2.5 mb-2">
          <div className="w-9 h-9 bg-blue-600 rounded-xl flex items-center justify-center text-white font-extrabold text-lg shadow-sm">+</div>
          <h2 className="text-2xl font-extrabold text-slate-900">Create Skill Group</h2>
        </div>
        <p className="text-sm text-slate-500 mb-6">Build a project team and match automatically with students who possess complementary skills.</p>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Group Name *</label>
            <input
              type="text"
              value={form.name}
              onChange={e => setForm({...form, name: e.target.value})}
              placeholder="e.g. AI Resume Analyzer"
              className="w-full px-4 py-3 border border-slate-200 rounded-xl text-sm bg-slate-50 focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500"
            />
            {errors.name && <p className="text-xs text-red-500 font-semibold mt-1">{errors.name}</p>}
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Project Description *</label>
            <textarea
              value={form.description}
              onChange={e => setForm({...form, description: e.target.value})}
              placeholder="Describe your project goal, vision, and what roles you need..."
              rows={3}
              className="w-full px-4 py-3 border border-slate-200 rounded-xl text-sm bg-slate-50 focus:outline-none focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 resize-none"
            />
            {errors.description && <p className="text-xs text-red-500 font-semibold mt-1">{errors.description}</p>}
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Required Skills for Team *</label>
            <div className="flex flex-wrap gap-1.5 max-h-40 overflow-y-auto p-3 border border-slate-200 rounded-xl bg-slate-50 mb-2">
              {SKILLS_LIST.map(skill => (
                <button
                  type="button"
                  key={skill}
                  onClick={() => toggleSkill(skill)}
                  className={`px-3 py-1.5 rounded-lg border text-xs font-semibold transition-all ${form.requiredSkills.includes(skill) ? "bg-blue-600 border-blue-600 text-white shadow-xs" : "bg-white border-slate-200 text-slate-600 hover:border-blue-300"}`}
                >
                  {skill} {form.requiredSkills.includes(skill) && "✓"}
                </button>
              ))}
            </div>
            {errors.skills && <p className="text-xs text-red-500 font-semibold">{errors.skills}</p>}

            <div className="flex gap-2 mt-2">
              <input
                type="text"
                value={customSkill}
                onChange={e => setCustomSkill(e.target.value)}
                placeholder="Add custom skill..."
                className="flex-1 px-3 py-1.5 border border-slate-200 rounded-lg text-xs bg-white focus:outline-none"
              />
              <button type="button" onClick={addCustomSkill} className="px-3 py-1.5 bg-slate-900 text-white text-xs font-bold rounded-lg hover:bg-slate-800">+ Add</button>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Team Size</label>
              <select value={form.maxMembers} onChange={e => setForm({...form, maxMembers: e.target.value})} className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-xs bg-slate-50">
                {TEAM_SIZES.map(s => <option key={s} value={parseInt(s, 10)}>{s}</option>)}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Group Type</label>
              <select value={form.projectType} onChange={e => setForm({...form, projectType: e.target.value})} className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-xs bg-slate-50">
                {GROUP_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">Visibility</label>
              <select value={form.visibility} onChange={e => setForm({...form, visibility: e.target.value})} className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-xs bg-slate-50">
                {["Public", "College Only", "Invite Only"].map(v => <option key={v} value={v}>{v}</option>)}
              </select>
            </div>
          </div>

          <div className="pt-3 flex gap-3">
            <button type="button" onClick={onClose} className="flex-1 py-3 border border-slate-200 text-slate-600 font-semibold rounded-xl hover:bg-slate-50 text-sm">Cancel</button>
            <button type="submit" className="flex-1 py-3 bg-blue-600 text-white font-extrabold rounded-xl hover:bg-blue-700 shadow-md text-sm">Create Group →</button>
          </div>
        </form>
      </div>
    </div>
  );
};

// ─── CANDIDATE PROFILE MODAL ──────────────────────────────────
const UserProfileModal = ({ candidateUser, onClose, onInviteUser, groupRequiredSkills = [] }) => {
  if (!candidateUser) return null;
  const match = calculateSkillMatch(groupRequiredSkills, candidateUser);
  const initials = (candidateUser.name || "U").substring(0, 2).toUpperCase();

  return (
    <div className="fixed inset-0 z-[9500] flex items-center justify-center p-4" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-sm" />
      <div className="relative bg-white rounded-3xl shadow-2xl w-full max-w-md p-6 sm:p-7 fade-up">
        <button onClick={onClose} className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 font-bold">✕</button>

        <div className="text-center mb-5">
          <div className={`w-16 h-16 rounded-2xl ${getAvatarBg(initials)} flex items-center justify-center text-white font-extrabold text-xl mx-auto mb-3 shadow-sm`}>
            {initials}
          </div>
          <h3 className="font-extrabold text-slate-900 text-lg">{candidateUser.name}</h3>
          <p className="text-xs text-slate-500">{candidateUser.college || "University"} · {candidateUser.year || ""}</p>
          <span className="inline-block mt-2 px-3 py-1 bg-emerald-50 text-emerald-700 border border-emerald-100 rounded-full text-xs font-extrabold">
            {match.matchPercent}% Skill Match · {match.matchReason}
          </span>
        </div>

        {candidateUser.bio && (
          <p className="text-xs text-slate-600 bg-slate-50 p-3 rounded-xl mb-4 leading-relaxed">
            "{candidateUser.bio}"
          </p>
        )}

        <div className="space-y-3 mb-6">
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Primary Skills</span>
            <div className="flex flex-wrap gap-1">
              {(candidateUser.skills || []).map(sk => (
                <span key={sk} className="px-2.5 py-1 bg-blue-50 text-blue-700 border border-blue-100 rounded-lg text-xs font-semibold">
                  {sk}
                </span>
              ))}
            </div>
          </div>

          {candidateUser.secondarySkills && candidateUser.secondarySkills.length > 0 && (
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Secondary Skills</span>
              <div className="flex flex-wrap gap-1">
                {candidateUser.secondarySkills.map(sk => (
                  <span key={sk} className="px-2 py-0.5 bg-slate-100 text-slate-600 rounded text-xs font-medium">
                    {sk}
                  </span>
                ))}
              </div>
            </div>
          )}

          {candidateUser.githubUrl && (
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Supporting GitHub</span>
              <a href={candidateUser.githubUrl} target="_blank" rel="noopener noreferrer" className="text-xs text-blue-600 font-bold hover:underline flex items-center gap-1">
                <span>🐙</span> {candidateUser.githubUrl}
              </a>
            </div>
          )}
        </div>

        <button
          onClick={() => {
            onInviteUser(candidateUser);
            onClose();
          }}
          className="w-full py-3 bg-blue-600 text-white font-extrabold text-xs rounded-xl hover:bg-blue-700 shadow-sm transition-colors"
        >
          + Invite to Skill Group
        </button>
      </div>
    </div>
  );
};

// ─── AUTH MODAL ───────────────────────────────────────────────
const AuthModal = ({ mode, onClose, onSuccess }) => {
  const [tab, setTab] = useState(mode);
  const [form, setForm] = useState({ name: "", email: "", password: "", confirmPassword: "" });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  const API_BASE = window.SKILLSYNC_API_URL || "http://localhost:5000/api";

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.email.trim() || !form.password) {
      setErrors({ submit: "Please fill in all required fields." });
      return;
    }

    setLoading(true);
    setErrors({});

    const normalizedEmail = form.email.trim().toLowerCase();

    try {
      const endpoint = tab === "signup" ? "/auth/signup" : "/auth/login";
      const res = await fetch(`${API_BASE}${endpoint}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.name.trim(),
          email: normalizedEmail,
          password: form.password,
          confirmPassword: form.confirmPassword,
        }),
      });

      const data = await res.json().catch(() => ({}));

      if (res.ok && data.user) {
        const authUser = {
          ...data.user,
          uid: data.user._id,
          displayName: data.user.name,
          isNewUser: tab === "signup" || !data.user.onboardingCompleted,
        };
        safeSetStorage("skillsync_user", authUser);
        if (data.token) localStorage.setItem("skillsync_token", data.token);
        setLoading(false);
        onSuccess(authUser);
        return;
      }
    } catch (err) {
      console.warn("Backend API notice:", err.message);
    }

    const demoUser = {
      uid: "usr_" + Date.now(),
      _id: "usr_" + Date.now(),
      name: tab === "signup" ? form.name.trim() : "SkillSync Student",
      displayName: tab === "signup" ? form.name.trim() : "SkillSync Student",
      email: normalizedEmail,
      role: "student",
      isNewUser: tab === "signup",
      onboardingCompleted: tab === "signin",
      skills: ["Python", "React", "Machine Learning"],
      secondarySkills: ["Node.js", "UI/UX"],
      learningSkills: ["Deep Learning"],
      interests: ["Hackathon", "Startup"],
      college: "Silver Oak University",
      year: "4th Year"
    };

    safeSetStorage("skillsync_user", demoUser);
    localStorage.setItem("skillsync_token", "token-active");
    setLoading(false);
    onSuccess(demoUser);
  };

  return (
    <div className="fixed inset-0 z-[9000] flex items-center justify-center p-4" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="absolute inset-0 bg-slate-950/55 backdrop-blur-sm" />
      <div className="relative bg-white rounded-3xl shadow-2xl w-full max-w-md p-7 sm:p-8 overflow-hidden fade-up">
        <button onClick={onClose} className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 font-bold">✕</button>

        <div className="flex items-center gap-2 mb-6">
          <div className="w-9 h-9 bg-blue-600 rounded-xl flex items-center justify-center text-white font-bold">S</div>
          <span className="font-extrabold text-lg text-slate-900">SkillSync <span className="text-blue-600">AI</span></span>
        </div>

        <h2 className="text-2xl font-extrabold text-slate-900">{tab === "signup" ? "Create your Skill Profile" : "Welcome back"}</h2>
        <p className="text-xs text-slate-500 mt-1 mb-6">{tab === "signup" ? "Connect with students who possess complementary skills." : "Sign in to access your Skill Groups & matches."}</p>

        <div className="flex bg-slate-100 rounded-xl p-1 mb-6">
          {["signin", "signup"].map((t) => (
            <button key={t} type="button" onClick={() => setTab(t)} className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${tab === t ? "bg-white text-slate-900 shadow-sm" : "text-slate-500"}`}>
              {t === "signin" ? "Sign In" : "Create Account"}
            </button>
          ))}
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {tab === "signup" && (
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Full Name</label>
              <input type="text" required value={form.name} onChange={e => setForm({...form, name: e.target.value})} placeholder="Your full name" className="w-full px-4 py-2.5 border rounded-xl text-sm bg-slate-50 focus:outline-none focus:ring-2 focus:ring-blue-500/30"/>
            </div>
          )}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Email Address</label>
            <input type="email" required value={form.email} onChange={e => setForm({...form, email: e.target.value})} placeholder="you@college.edu" className="w-full px-4 py-2.5 border rounded-xl text-sm bg-slate-50 focus:outline-none focus:ring-2 focus:ring-blue-500/30"/>
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Password</label>
            <input type="password" required value={form.password} onChange={e => setForm({...form, password: e.target.value})} placeholder="Minimum 8 characters" className="w-full px-4 py-2.5 border rounded-xl text-sm bg-slate-50 focus:outline-none focus:ring-2 focus:ring-blue-500/30"/>
          </div>

          <button type="submit" disabled={loading} className="w-full py-3 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 transition-colors shadow-sm">
            {loading ? "Processing..." : (tab === "signin" ? "Sign In →" : "Create Skill Profile →")}
          </button>
        </form>
      </div>
    </div>
  );
};

// ─── ONBOARDING (SKILL PROFILE SETUP) ────────────────────────
const Onboarding = ({ user, onComplete }) => {
  const [step, setStep] = useState(1);
  const TOTAL = 4;

  const [profile, setProfile] = useState({
    displayName: user?.displayName || "",
    college: "Silver Oak University",
    year: "4th Year",
    primarySkills: ["Python", "React", "Machine Learning"],
    secondarySkills: ["UI/UX", "Node.js"],
    learningSkills: ["Deep Learning"],
    interests: ["Hackathon", "Startup"],
    preferredTeamSize: "4 Members",
    bio: "",
    githubUrl: user?.githubUrl || ""
  });

  const toggleArray = (field, val) => {
    setProfile(p => ({
      ...p,
      [field]: p[field].includes(val) ? p[field].filter(x => x !== val) : [...p[field], val]
    }));
  };

  const steps = [
    // Step 1: Basic Info
    () => (
      <div className="space-y-4">
        <h2 className="text-2xl font-extrabold text-slate-900">Skill Profile Setup 👋</h2>
        <p className="text-xs text-slate-500">Tell us your college details so we can match you with nearby skill groups.</p>
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">Full Name *</label>
          <input value={profile.displayName} onChange={e => setProfile({...profile, displayName: e.target.value})} className="w-full px-4 py-3 border border-slate-200 rounded-xl text-sm bg-slate-50 focus:outline-none focus:ring-2 focus:ring-blue-500/30"/>
        </div>
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">College / University *</label>
          <select value={profile.college} onChange={e => setProfile({...profile, college: e.target.value})} className="w-full px-4 py-3 border border-slate-200 rounded-xl text-sm bg-slate-50">
            {COLLEGES.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">Academic Year</label>
          <div className="grid grid-cols-3 gap-2">
            {YEARS.map(y => (
              <button key={y} type="button" onClick={() => setProfile({...profile, year: y})} className={`py-2 rounded-lg border text-xs font-semibold ${profile.year === y ? "bg-blue-600 border-blue-600 text-white" : "border-slate-200 text-slate-600"}`}>{y}</button>
            ))}
          </div>
        </div>
      </div>
    ),
    // Step 2: Primary & Secondary Skills
    () => (
      <div className="space-y-4">
        <h2 className="text-2xl font-extrabold text-slate-900">Your Skills & Expertise 🛠️</h2>
        <p className="text-xs text-slate-500">Select your primary and secondary technical or design skills.</p>
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">Primary Skills (Strongest)</label>
          <div className="flex flex-wrap gap-1.5 max-h-36 overflow-y-auto p-2 border border-slate-200 rounded-xl bg-slate-50">
            {SKILLS_LIST.map(s => (
              <button key={s} type="button" onClick={() => toggleArray("primarySkills", s)} className={`px-3 py-1.5 rounded-lg border text-xs font-semibold ${profile.primarySkills.includes(s) ? "bg-blue-600 border-blue-600 text-white" : "bg-white border-slate-200 text-slate-600"}`}>{s} {profile.primarySkills.includes(s) && "✓"}</button>
            ))}
          </div>
        </div>
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">Secondary Skills (Familiar)</label>
          <div className="flex flex-wrap gap-1.5 max-h-32 overflow-y-auto p-2 border border-slate-200 rounded-xl bg-slate-50">
            {SKILLS_LIST.map(s => (
              <button key={s} type="button" onClick={() => toggleArray("secondarySkills", s)} className={`px-2.5 py-1 rounded-lg border text-xs font-medium ${profile.secondarySkills.includes(s) ? "bg-indigo-600 border-indigo-600 text-white" : "bg-white border-slate-200 text-slate-600"}`}>{s} {profile.secondarySkills.includes(s) && "✓"}</button>
            ))}
          </div>
        </div>
      </div>
    ),
    // Step 3: Skills to Learn & Team Preferences
    () => (
      <div className="space-y-4">
        <h2 className="text-2xl font-extrabold text-slate-900">Learning & Team Preferences 🎯</h2>
        <p className="text-xs text-slate-500">What skills do you want to learn, and what team size do you prefer?</p>
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">Skills You Want To Learn</label>
          <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto p-2 border border-slate-200 rounded-xl bg-slate-50">
            {SKILLS_LIST.slice(0, 12).map(s => (
              <button key={s} type="button" onClick={() => toggleArray("learningSkills", s)} className={`px-2.5 py-1 rounded-lg border text-xs font-medium ${profile.learningSkills.includes(s) ? "bg-emerald-600 border-emerald-600 text-white" : "bg-white border-slate-200 text-slate-600"}`}>{s} {profile.learningSkills.includes(s) && "✓"}</button>
            ))}
          </div>
        </div>
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">Project Interests</label>
          <div className="grid grid-cols-2 gap-2">
            {GROUP_TYPES.map(t => (
              <button key={t} type="button" onClick={() => toggleArray("interests", t)} className={`py-2 px-3 rounded-xl border text-xs font-semibold text-left ${profile.interests.includes(t) ? "bg-blue-600 border-blue-600 text-white" : "border-slate-200 text-slate-600"}`}>{t}</button>
            ))}
          </div>
        </div>
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">Preferred Team Size</label>
          <select value={profile.preferredTeamSize} onChange={e => setProfile({...profile, preferredTeamSize: e.target.value})} className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs bg-slate-50">
            {TEAM_SIZES.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
      </div>
    ),
    // Step 4: GitHub Link (Supporting)
    () => (
      <div className="space-y-4">
        <h2 className="text-2xl font-extrabold text-slate-900">Almost Done! ✨</h2>
        <p className="text-xs text-slate-500">Add an optional GitHub profile to display your repositories inside your profile.</p>
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">GitHub Profile URL (Optional Supporting Link)</label>
          <input value={profile.githubUrl} onChange={e => setProfile({...profile, githubUrl: e.target.value})} placeholder="https://github.com/yourusername" className="w-full px-4 py-3 border border-slate-200 rounded-xl text-sm bg-slate-50 focus:outline-none"/>
        </div>
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">Short Bio</label>
          <textarea value={profile.bio} onChange={e => setProfile({...profile, bio: e.target.value})} placeholder="Tell teammates what you love building..." rows={3} className="w-full px-4 py-3 border border-slate-200 rounded-xl text-sm bg-slate-50 resize-none"/>
        </div>
      </div>
    )
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4 pt-24">
      <div className="bg-white rounded-3xl shadow-xl w-full max-w-lg p-6 sm:p-8">
        <div className="mb-6">
          <div className="flex justify-between text-xs text-slate-400 font-bold mb-1">
            <span>SKILL PROFILE SETUP</span>
            <span>Step {step} of {TOTAL}</span>
          </div>
          <div className="h-2 bg-slate-100 rounded-full">
            <div className="h-2 bg-blue-600 rounded-full transition-all" style={{ width: `${(step/TOTAL)*100}%` }} />
          </div>
        </div>
        <div>{steps[step - 1]()}</div>
        <div className="mt-8 flex gap-3">
          {step > 1 && <button onClick={() => setStep(s=>s-1)} className="flex-1 py-3 border border-slate-200 text-slate-600 font-bold text-sm rounded-xl">← Back</button>}
          <button onClick={() => { if (step < TOTAL) setStep(s=>s+1); else onComplete({ ...user, ...profile, skills: profile.primarySkills }); }} className="flex-1 py-3 bg-blue-600 text-white font-bold text-sm rounded-xl hover:bg-blue-700">
            {step === TOTAL ? "Save & Match Teammates →" : "Continue →"}
          </button>
        </div>
      </div>
    </div>
  );
};

// ─── MAIN DASHBOARD ───────────────────────────────────────────
const Dashboard = ({ user, setPage, groups = [], users = [], invitations = [], onOpenCreateGroupModal, onInviteUser, onAcceptInvite, onDeclineInvite, setMatchModalGroup, setSelectedCandidate }) => {

  const userSkills = user?.skills || ["Python", "React"];

  // Calculate Match Score for Groups
  const recommendedGroups = groups.map(grp => {
    const match = calculateSkillMatch(grp.requiredSkills, user);
    return { ...grp, ...match };
  }).sort((a, b) => b.matchPercent - a.matchPercent);

  // Recommended Teammates (Exclude current user)
  const candidateUsers = users.filter(u => u.id !== user?.id && u.email !== user?.email);

  return (
    <div className="min-h-screen bg-slate-50 pt-20 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">

        {/* Hero Section — Core Purpose */}
        <div className="bg-gradient-to-r from-blue-700 via-blue-600 to-indigo-700 rounded-3xl p-8 sm:p-10 text-white shadow-xl mb-8 relative overflow-hidden">
          <div className="relative z-10 max-w-2xl">
            <span className="inline-block px-3 py-1 bg-white/15 backdrop-blur-md rounded-full text-xs font-bold text-blue-100 mb-4 border border-white/20">
              ⚡ Skill-Based Team Builder
            </span>
            <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight mb-3 leading-tight">
              Find Your Skill Team
            </h1>
            <p className="text-blue-100 text-sm sm:text-base mb-8 leading-relaxed opacity-95">
              Build teams with people whose skills complement yours. Match by skills, project goals, and hackathon requirements.
            </p>
            <div className="flex flex-wrap gap-4">
              <button
                onClick={onOpenCreateGroupModal}
                className="px-6 py-3.5 bg-white text-blue-700 font-extrabold text-sm rounded-xl hover:bg-blue-50 transition-all shadow-md hover:shadow-lg flex items-center gap-2"
              >
                <span className="text-lg">+</span> Create Skill Group
              </button>
              <button
                onClick={() => setPage("discover")}
                className="px-6 py-3.5 bg-blue-800/60 hover:bg-blue-800 border border-white/20 text-white font-bold text-sm rounded-xl transition-all flex items-center gap-2"
              >
                <span>🔍</span> Find People by Skills
              </button>
            </div>
          </div>
        </div>

        {/* Pending Invitations Alert */}
        {invitations.filter(i => i.status === 'pending').length > 0 && (
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5 mb-8 flex items-center justify-between shadow-xs">
            <div className="flex items-center gap-3">
              <span className="text-2xl">✉️</span>
              <div>
                <h4 className="font-bold text-amber-900 text-sm">
                  You have {invitations.filter(i => i.status === 'pending').length} pending group invitation(s)!
                </h4>
                <p className="text-xs text-amber-700 mt-0.5">Review your skill team invitations in your My Groups workspace.</p>
              </div>
            </div>
            <button
              onClick={() => setPage("my-groups")}
              className="px-4 py-2 bg-amber-600 text-white font-bold text-xs rounded-xl hover:bg-amber-700 transition-colors"
            >
              View Invitations →
            </button>
          </div>
        )}

        <div className="grid lg:grid-cols-3 gap-8">

          {/* Left Column: Recommended Groups & Skill Teammates */}
          <div className="lg:col-span-2 space-y-8">

            {/* Recommended Skill Groups */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-xl font-extrabold text-slate-900">Recommended Skill Groups</h2>
                  <p className="text-xs text-slate-500">Groups matching your primary skills: {userSkills.join(", ")}</p>
                </div>
                <button onClick={() => setPage("discover")} className="text-xs text-blue-600 font-bold hover:underline">
                  View All Groups ({groups.length}) →
                </button>
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                {recommendedGroups.slice(0, 4).map(grp => (
                  <div key={grp.id} className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs hover:shadow-md transition-all flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between gap-2 mb-2">
                        <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-100">
                          {grp.projectType || "Hackathon"}
                        </span>
                        <span className="px-2 py-0.5 rounded-md text-[11px] font-extrabold bg-emerald-50 text-emerald-700 border border-emerald-200">
                          {grp.matchPercent}% Skill Match
                        </span>
                      </div>
                      <h3 className="font-extrabold text-slate-900 text-base mb-1.5 leading-snug">{grp.name}</h3>
                      <p className="text-xs text-slate-500 mb-3 line-clamp-2 leading-relaxed">{grp.description}</p>
                      
                      <div className="mb-3">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Required Skills:</span>
                        <div className="flex flex-wrap gap-1">
                          {(grp.requiredSkills || []).map(sk => (
                            <span key={sk} className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded-md text-xs font-semibold">
                              {sk}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                      <span className="text-xs font-semibold text-slate-400">
                        👥 {grp.members?.length || 1}/{grp.maxMembers || 4} Members
                      </span>
                      <button
                        onClick={() => setMatchModalGroup(grp)}
                        className="px-3.5 py-1.5 bg-blue-600 text-white font-bold text-xs rounded-lg hover:bg-blue-700 transition-colors"
                      >
                        View & Match →
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Recommended Skill Teammates (Match Percentage) */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-xl font-extrabold text-slate-900">Recommended Teammates</h2>
                  <p className="text-xs text-slate-500">Students with complementary skills for your project groups.</p>
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                {candidateUsers.slice(0, 4).map(cand => {
                  const match = calculateSkillMatch(userSkills, cand);
                  return (
                    <div key={cand.id} className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs hover:shadow-md transition-all flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-3">
                            <div className={`w-11 h-11 rounded-full ${getAvatarBg(cand.name.substring(0, 2))} flex items-center justify-center text-white font-extrabold text-sm`}>
                              {cand.name.substring(0, 2).toUpperCase()}
                            </div>
                            <div>
                              <h4 className="font-bold text-slate-900 text-sm leading-tight">{cand.name}</h4>
                              <p className="text-xs text-slate-400">{cand.college || "University"} · {cand.year || ""}</p>
                            </div>
                          </div>
                          <span className="px-2.5 py-1 rounded-full text-xs font-extrabold bg-blue-50 text-blue-700 border border-blue-100">
                            {match.matchPercent}% Match
                          </span>
                        </div>

                        <span className="inline-block px-2.5 py-0.5 bg-slate-100 text-slate-600 rounded-md text-[11px] font-semibold mb-3">
                          💡 {match.matchReason}
                        </span>

                        <div className="flex flex-wrap gap-1 mb-4">
                          {(cand.skills || []).map(sk => (
                            <span key={sk} className="px-2 py-0.5 bg-blue-50/60 text-blue-700 border border-blue-100 rounded-md text-xs font-semibold">
                              {sk}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <button
                          onClick={() => onInviteUser(cand)}
                          className="flex-1 py-2 bg-blue-600 text-white font-bold text-xs rounded-xl hover:bg-blue-700 transition-colors"
                        >
                          + Invite
                        </button>
                        <button
                          onClick={() => setSelectedCandidate(cand)}
                          className="px-3 py-2 border border-slate-200 text-slate-600 hover:text-slate-900 font-bold text-xs rounded-xl hover:bg-slate-50 transition-colors"
                        >
                          View Profile
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

          </div>

          {/* Right Column: Quick Stats & My Groups Summary */}
          <div className="space-y-6">
            {/* My Groups Quick Workspace */}
            <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-extrabold text-slate-900 text-base">My Groups Workspace</h3>
                <button onClick={() => setPage("my-groups")} className="text-xs text-blue-600 font-bold hover:underline">
                  Manage →
                </button>
              </div>

              <div className="space-y-3">
                <div className="p-3 bg-slate-50 border border-slate-100 rounded-xl flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700">Created Groups</span>
                  <span className="font-extrabold text-slate-900 text-sm">
                    {groups.filter(g => g.creator?.id === user?.id || g.creator?.name === user?.displayName).length}
                  </span>
                </div>
                <div className="p-3 bg-slate-50 border border-slate-100 rounded-xl flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700">Joined Groups</span>
                  <span className="font-extrabold text-slate-900 text-sm">
                    {groups.filter(g => (g.members || []).some(m => m.id === user?.id || m.name === user?.displayName)).length}
                  </span>
                </div>
                <div className="p-3 bg-amber-50/60 border border-amber-100 rounded-xl flex items-center justify-between">
                  <span className="text-xs font-bold text-amber-900">Pending Invitations</span>
                  <span className="font-extrabold text-amber-700 text-sm">
                    {invitations.filter(i => i.status === 'pending').length}
                  </span>
                </div>
              </div>

              <button
                onClick={onOpenCreateGroupModal}
                className="w-full mt-5 py-3 bg-slate-900 text-white font-bold text-xs rounded-xl hover:bg-slate-800 transition-colors shadow-xs"
              >
                + Create New Skill Group
              </button>
            </div>

            {/* Recent Group Activity */}
            <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs">
              <h3 className="font-extrabold text-slate-900 text-base mb-4">Recent Activity</h3>
              <div className="space-y-3">
                {groups.slice(0, 3).map(g => (
                  <div key={g.id} className="flex gap-3 text-xs">
                    <span className="text-base flex-shrink-0">⚡</span>
                    <div>
                      <p className="text-slate-700 font-semibold">
                        Group <strong className="text-slate-900">"{g.name}"</strong> looking for {g.requiredSkills?.join(", ")}
                      </p>
                      <p className="text-slate-400 mt-0.5">{formatDateRelative(g.createdAt)}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

// ─── DISCOVER SKILL GROUPS PAGE ──────────────────────────────
const DiscoverPage = ({ groups = [], users = [], user, onOpenCreateGroupModal, onJoinGroup, setMatchModalGroup }) => {
  const [search, setSearch] = useState("");
  const [selectedType, setSelectedType] = useState("All");

  const filteredGroups = groups.filter(grp => {
    const matchSearch =
      !search ||
      grp.name.toLowerCase().includes(search.toLowerCase()) ||
      grp.description.toLowerCase().includes(search.toLowerCase()) ||
      (grp.requiredSkills || []).some(s => s.toLowerCase().includes(search.toLowerCase()));
    
    const matchType = selectedType === "All" || grp.projectType === selectedType;
    return matchSearch && matchType;
  });

  return (
    <div className="min-h-screen bg-slate-50 pt-20 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl font-extrabold text-slate-900">Discover Skill Groups</h1>
            <p className="text-slate-500 text-sm">Find active project teams needing your exact skill set.</p>
          </div>
          <button
            onClick={onOpenCreateGroupModal}
            className="px-5 py-2.5 bg-blue-600 text-white font-bold text-xs rounded-xl hover:bg-blue-700 shadow-sm"
          >
            + Create Skill Group
          </button>
        </div>

        {/* Filter Bar */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 mb-8 shadow-xs flex flex-col md:flex-row gap-4 justify-between">
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search groups by name, description, or required skills..."
            className="flex-1 px-4 py-2.5 border border-slate-200 rounded-xl text-sm bg-slate-50 focus:outline-none focus:ring-2 focus:ring-blue-500/30"
          />

          <div className="flex flex-wrap gap-1.5">
            {["All", ...GROUP_TYPES].map(type => (
              <button
                key={type}
                onClick={() => setSelectedType(type)}
                className={`px-3 py-2 rounded-xl text-xs font-semibold transition-all ${selectedType === type ? "bg-blue-600 text-white shadow-xs" : "bg-slate-100 text-slate-600 hover:bg-slate-200"}`}
              >
                {type}
              </button>
            ))}
          </div>
        </div>

        {/* Group Cards Grid */}
        {filteredGroups.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredGroups.map(grp => {
              const match = calculateSkillMatch(grp.requiredSkills, user);
              const isMember = (grp.members || []).some(m => m.id === user?.id || m.name === user?.displayName);
              return (
                <div key={grp.id} className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs hover:shadow-md transition-all flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-100">
                        {grp.projectType}
                      </span>
                      <span className="px-2.5 py-0.5 rounded-full text-xs font-extrabold bg-emerald-50 text-emerald-700 border border-emerald-100">
                        {match.matchPercent}% Match
                      </span>
                    </div>

                    <h3 className="font-extrabold text-slate-900 text-lg mb-1">{grp.name}</h3>
                    <p className="text-xs text-slate-500 mb-4 leading-relaxed line-clamp-3">{grp.description}</p>

                    <div className="mb-4">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">Required Skills:</span>
                      <div className="flex flex-wrap gap-1">
                        {(grp.requiredSkills || []).map(sk => (
                          <span key={sk} className="px-2.5 py-1 bg-slate-100 text-slate-700 rounded-lg text-xs font-semibold">
                            {sk}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-slate-100 flex items-center justify-between gap-2">
                    <span className="text-xs font-bold text-slate-500">
                      👥 {grp.members?.length || 1}/{grp.maxMembers || 4} Members
                    </span>
                    <button
                      onClick={() => onJoinGroup(grp)}
                      disabled={isMember}
                      className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors ${isMember ? "bg-slate-100 text-slate-400 cursor-not-allowed" : "bg-blue-600 text-white hover:bg-blue-700"}`}
                    >
                      {isMember ? "Joined ✓" : "Join Group →"}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center">
            <div className="text-4xl mb-3">🔍</div>
            <h3 className="font-extrabold text-slate-900 text-base mb-1">No Skill Groups Found</h3>
            <p className="text-xs text-slate-500 max-w-md mx-auto mb-4">Create your own skill group to start building a project team with compatible students.</p>
            <button onClick={onOpenCreateGroupModal} className="px-5 py-2.5 bg-blue-600 text-white font-bold text-xs rounded-xl hover:bg-blue-700">+ Create Skill Group</button>
          </div>
        )}

      </div>
    </div>
  );
};

// ─── MY GROUPS PAGE ───────────────────────────────────────────
const MyGroupsPage = ({ groups = [], invitations = [], joinRequests = [], user, onOpenCreateGroupModal, onAcceptInvite, onDeclineInvite, onApproveRequest, onRejectRequest }) => {
  const [activeTab, setActiveTab] = useState("created");

  const createdGroups = groups.filter(g => g.creator?.id === user?.id || g.creator?.name === user?.displayName);
  const joinedGroups = groups.filter(g => (g.members || []).some(m => m.id === user?.id || m.name === user?.displayName));
  const pendingInvites = invitations.filter(i => i.status === 'pending');

  return (
    <div className="min-h-screen bg-slate-50 pt-20 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl font-extrabold text-slate-900">My Skill Groups Workspace</h1>
            <p className="text-slate-500 text-sm">Manage your created teams, joined groups, and pending invitations.</p>
          </div>
          <button onClick={onOpenCreateGroupModal} className="px-5 py-2.5 bg-blue-600 text-white font-bold text-xs rounded-xl hover:bg-blue-700 shadow-sm">+ Create Skill Group</button>
        </div>

        {/* Tab Selector */}
        <div className="flex border-b border-slate-200 mb-8 overflow-x-auto">
          {[
            { id: "created", label: `Groups I Created (${createdGroups.length})` },
            { id: "joined", label: `Groups I Joined (${joinedGroups.length})` },
            { id: "invites", label: `Pending Invitations (${pendingInvites.length})` },
            { id: "requests", label: `Join Requests (${joinRequests.length})` },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-5 py-3 text-xs font-extrabold border-b-2 transition-all whitespace-nowrap ${activeTab === tab.id ? "border-blue-600 text-blue-600" : "border-transparent text-slate-500 hover:text-slate-800"}`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* TAB 1: Created Groups */}
        {activeTab === "created" && (
          <div className="space-y-4">
            {createdGroups.length > 0 ? (
              createdGroups.map(grp => (
                <div key={grp.id} className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                    <div>
                      <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-100">{grp.projectType}</span>
                      <h3 className="font-extrabold text-slate-900 text-lg mt-1">{grp.name}</h3>
                    </div>
                    <span className="text-xs font-bold text-slate-400">Team Progress: {grp.members?.length || 1}/{grp.maxMembers || 4} Members</span>
                  </div>

                  <p className="text-xs text-slate-600 mb-4 leading-relaxed">{grp.description}</p>

                  <div className="mb-4">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Required Team Skills:</span>
                    <div className="flex flex-wrap gap-1">
                      {(grp.requiredSkills || []).map(sk => <span key={sk} className="px-2.5 py-1 bg-slate-100 text-slate-700 rounded-lg text-xs font-semibold">{sk}</span>)}
                    </div>
                  </div>

                  <div className="bg-slate-50 rounded-xl p-4 border border-slate-100">
                    <span className="text-xs font-bold text-slate-700 block mb-2">Team Members:</span>
                    <div className="flex flex-wrap gap-2">
                      {(grp.members || []).map((m, idx) => (
                        <span key={idx} className="px-3 py-1 bg-white border border-slate-200 rounded-lg text-xs font-bold text-slate-800 flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                          {m.name || m.displayName || "Member"}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center text-slate-500 text-xs">
                You haven't created any skill groups yet. Click "+ Create Skill Group" above to start your first team.
              </div>
            )}
          </div>
        )}

        {/* TAB 2: Joined Groups */}
        {activeTab === "joined" && (
          <div className="space-y-4">
            {joinedGroups.length > 0 ? (
              joinedGroups.map(grp => (
                <div key={grp.id} className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs">
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-100">Member</span>
                  <h3 className="font-extrabold text-slate-900 text-lg mt-2 mb-1">{grp.name}</h3>
                  <p className="text-xs text-slate-600 mb-4 leading-relaxed">{grp.description}</p>

                  <div className="flex flex-wrap gap-1 mb-4">
                    {(grp.requiredSkills || []).map(sk => <span key={sk} className="px-2.5 py-1 bg-slate-100 text-slate-700 rounded-lg text-xs font-semibold">{sk}</span>)}
                  </div>
                </div>
              ))
            ) : (
              <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center text-slate-500 text-xs">
                You are not currently a member of any other skill groups. Explore groups in the Discover tab.
              </div>
            )}
          </div>
        )}

        {/* TAB 3: Pending Invitations */}
        {activeTab === "invites" && (
          <div className="space-y-4">
            {pendingInvites.length > 0 ? (
              pendingInvites.map(inv => (
                <div key={inv.id} className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-base">✉️</span>
                      <h4 className="font-extrabold text-slate-900 text-base">Invitation to join "{inv.group?.name}"</h4>
                    </div>
                    <p className="text-xs text-slate-500">From {inv.sender?.name} ({inv.sender?.college})</p>
                    <div className="flex flex-wrap gap-1 mt-2">
                      {(inv.group?.requiredSkills || []).map(sk => <span key={sk} className="px-2 py-0.5 bg-blue-50 text-blue-700 rounded text-xs font-semibold">{sk}</span>)}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={() => onDeclineInvite(inv.id)} className="px-4 py-2 border border-slate-200 text-slate-600 font-bold text-xs rounded-xl hover:bg-slate-50">Decline</button>
                    <button onClick={() => onAcceptInvite(inv)} className="px-5 py-2 bg-blue-600 text-white font-bold text-xs rounded-xl hover:bg-blue-700">Accept Invitation →</button>
                  </div>
                </div>
              ))
            ) : (
              <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center text-slate-500 text-xs">
                No pending invitations right now.
              </div>
            )}
          </div>
        )}

        {/* TAB 4: Join Requests */}
        {activeTab === "requests" && (
          <div className="space-y-4">
            {joinRequests.length > 0 ? (
              joinRequests.map(req => (
                <div key={req.id} className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h4 className="font-extrabold text-slate-900 text-base">{req.user?.name} requested to join "{req.group?.name}"</h4>
                    <p className="text-xs text-slate-500 mt-0.5">Message: {req.message || "Interested in joining your project team."}</p>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={() => onRejectRequest(req.id)} className="px-4 py-2 border border-slate-200 text-slate-600 font-bold text-xs rounded-xl">Reject</button>
                    <button onClick={() => onApproveRequest(req)} className="px-5 py-2 bg-emerald-600 text-white font-bold text-xs rounded-xl hover:bg-emerald-700">Approve & Add →</button>
                  </div>
                </div>
              ))
            ) : (
              <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center text-slate-500 text-xs">
                No pending join requests for your groups.
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
};

// ─── ALL SKILL TEAMS PAGE ─────────────────────────────────────
const TeamsPage = ({ groups = [], onOpenCreateGroupModal, onJoinGroup }) => {
  return (
    <div className="min-h-screen bg-slate-50 pt-20 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="mb-6 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-extrabold text-slate-900">All Skill Teams</h1>
            <p className="text-slate-500 text-sm">Browse all active student project groups across colleges.</p>
          </div>
          <button onClick={onOpenCreateGroupModal} className="px-5 py-2.5 bg-blue-600 text-white font-bold text-xs rounded-xl hover:bg-blue-700">+ Create Skill Group</button>
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          {groups.map(grp => (
            <div key={grp.id} className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-100">{grp.projectType}</span>
                  <span className="text-xs font-bold text-slate-400">👥 {grp.members?.length || 1}/{grp.maxMembers || 4} Members</span>
                </div>
                <h3 className="font-extrabold text-slate-900 text-base mb-1.5">{grp.name}</h3>
                <p className="text-xs text-slate-600 mb-4 leading-relaxed line-clamp-2">{grp.description}</p>
                <div className="flex flex-wrap gap-1 mb-4">
                  {(grp.requiredSkills || []).map(sk => <span key={sk} className="px-2.5 py-1 bg-slate-100 text-slate-700 rounded-lg text-xs font-semibold">{sk}</span>)}
                </div>
              </div>
              <button onClick={() => onJoinGroup(grp)} className="w-full py-2.5 bg-blue-600 text-white text-xs font-bold rounded-xl hover:bg-blue-700">Join Team →</button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// ─── CHAT PAGE ────────────────────────────────────────────────
const ChatPage = ({ users = [] }) => {
  return (
    <div className="min-h-screen bg-slate-50 pt-20 pb-10">
      <div className="max-w-5xl mx-auto px-4 sm:px-6">
        <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden h-[75vh] flex">
          <div className="w-1/3 border-r border-slate-200 p-4 space-y-3">
            <h2 className="font-extrabold text-slate-900 text-base">Teammate Messages</h2>
            <div className="space-y-2 overflow-y-auto max-h-[60vh]">
              {users.map(s => (
                <div key={s.id} className="p-3 hover:bg-slate-50 rounded-xl cursor-pointer transition-colors flex items-center gap-3">
                  <div className={`w-9 h-9 rounded-full ${getAvatarBg(s.name.substring(0,2))} flex items-center justify-center text-white text-xs font-bold`}>{s.name.substring(0,2).toUpperCase()}</div>
                  <div className="min-w-0">
                    <p className="font-semibold text-slate-900 text-xs truncate">{s.name}</p>
                    <p className="text-[11px] text-slate-400 truncate">Let's connect for project!</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="flex-1 flex flex-col justify-between p-6 bg-slate-50/50">
            <div className="text-center text-xs text-slate-400 py-10">Select a teammate conversation to view messages.</div>
            <div className="flex gap-2">
              <input type="text" placeholder="Type a message..." className="flex-1 px-4 py-2.5 border border-slate-200 rounded-xl text-sm bg-white focus:outline-none"/>
              <button className="px-5 py-2.5 bg-blue-600 text-white font-bold text-xs rounded-xl">Send</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// ─── SWAP PAGE ────────────────────────────────────────────────
const SwapPage = () => {
  return (
    <div className="min-h-screen bg-slate-50 pt-20 pb-10">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        <div className="mb-6">
          <h1 className="text-2xl font-extrabold text-slate-900">Hostel Room & Class Section Swap</h1>
          <p className="text-slate-500 text-sm">Find verified college peers to mutually swap room allocations or section batches.</p>
        </div>
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs text-center py-12">
          <div className="text-4xl mb-3">🔄</div>
          <h3 className="font-extrabold text-slate-900 text-base mb-1">Mutual Consent Swap Engine Active</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto mb-6">Post your current hostel room or class batch allocation to get matched with peers looking to swap.</p>
          <button className="px-5 py-2.5 bg-blue-600 text-white font-bold text-xs rounded-xl hover:bg-blue-700">+ Create Swap Request</button>
        </div>
      </div>
    </div>
  );
};

// ─── USER PROFILE PAGE (WITH SUPPORTING GITHUB) ────────────────
const ProfilePage = ({ user, setUser, githubProfile, setGithubProfile, githubRepos, setGithubRepos }) => {
  const [edit, setEdit] = useState(false);
  const [form, setForm] = useState({
    displayName: user?.displayName || "",
    college: user?.college || "",
    year: user?.year || "",
    skills: user?.skills || [],
    secondarySkills: user?.secondarySkills || [],
    learningSkills: user?.learningSkills || [],
    interests: user?.interests || [],
    bio: user?.bio || "",
    githubUrl: user?.githubUrl || ""
  });
  const [githubInput, setGithubInput] = useState(user?.githubUrl || "");
  const [connectingGitHub, setConnectingGitHub] = useState(false);
  const [toast, setToast] = useState(null);

  const save = () => {
    const updated = { ...user, ...form };
    setUser(updated);
    safeSetStorage("skillsync_user", updated);
    setEdit(false);
    setToast("Skill Profile updated successfully!");
  };

  const handleConnectGitHub = async () => {
    const cleanUser = extractGitHubUsername(githubInput);
    if (!cleanUser) {
      setToast("Please enter a valid GitHub username.");
      return;
    }
    setConnectingGitHub(true);
    try {
      const prof = await fetchGitHubProfile(cleanUser);
      const repos = await fetchGitHubRepos(cleanUser);
      setGithubProfile(prof);
      setGithubRepos(repos);
      setForm(p => ({ ...p, githubUrl: `https://github.com/${prof.login}` }));
      const updatedUser = { ...user, githubUrl: `https://github.com/${prof.login}` };
      setUser(updatedUser);
      safeSetStorage("skillsync_user", updatedUser);
      safeSetStorage("skillsync_github_profile", prof);
      safeSetStorage("skillsync_github_repositories", repos);
      setToast(`Connected @${prof.login} successfully!`);
    } catch (e) {
      setToast(e.message || "Failed to connect GitHub profile.");
    } finally {
      setConnectingGitHub(false);
    }
  };

  const initials = (form.displayName || "U").substring(0, 2).toUpperCase();

  return (
    <div className="min-h-screen bg-slate-50 pt-20 pb-10">
      {toast && <Toast message={toast} onClose={() => setToast(null)} />}
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        <div className="grid lg:grid-cols-3 gap-6">

          <div className="space-y-4">
            <div className="bg-white border border-slate-200 rounded-2xl p-6 text-center shadow-xs">
              <div className={`w-20 h-20 rounded-2xl ${getAvatarBg(initials)} flex items-center justify-center text-white font-extrabold text-2xl mx-auto mb-4`}>{initials}</div>
              <h2 className="font-extrabold text-slate-900 text-lg">{form.displayName || "Your Name"}</h2>
              <p className="text-blue-600 text-sm font-semibold">{form.college || "College"}</p>
              <p className="text-slate-400 text-xs mt-0.5">{form.year || ""}</p>
            </div>

            {/* Supporting GitHub Card in Profile */}
            {githubProfile ? (
              <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
                <div className="flex items-center gap-3 mb-3">
                  <img src={githubProfile.avatar_url} alt={githubProfile.login} className="w-12 h-12 rounded-full border border-slate-200 object-cover" />
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm">{githubProfile.name}</h4>
                    <p className="text-xs text-blue-600 font-semibold">@{githubProfile.login}</p>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-1 text-center bg-slate-50 rounded-xl p-2 text-xs font-bold text-slate-700 mb-3">
                  <div><div>{githubProfile.public_repos}</div><div className="text-[9px] text-slate-400 font-normal">Repos</div></div>
                  <div><div>{githubProfile.followers}</div><div className="text-[9px] text-slate-400 font-normal">Followers</div></div>
                  <div><div>{githubProfile.following}</div><div className="text-[9px] text-slate-400 font-normal">Following</div></div>
                </div>
                <a href={githubProfile.html_url} target="_blank" rel="noopener noreferrer" className="block text-center py-2 bg-slate-900 text-white text-xs font-bold rounded-lg">View GitHub Profile 🐙</a>
              </div>
            ) : (
              <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
                <h3 className="font-bold text-slate-900 text-sm mb-1">Supporting GitHub Profile</h3>
                <p className="text-xs text-slate-500 mb-3">Connect your GitHub account to showcase your repositories.</p>
                <div className="space-y-2">
                  <input type="text" value={githubInput} onChange={e => setGithubInput(e.target.value)} placeholder="https://github.com/username" className="w-full px-3 py-2 border rounded-lg text-xs bg-slate-50"/>
                  <button onClick={handleConnectGitHub} disabled={connectingGitHub} className="w-full py-2 bg-slate-900 text-white text-xs font-bold rounded-lg">{connectingGitHub ? "Connecting..." : "Connect GitHub"}</button>
                </div>
              </div>
            )}
          </div>

          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs">
              <div className="flex justify-between items-center mb-5">
                <h3 className="font-bold text-slate-900 text-lg">Skill Profile Details</h3>
                <button onClick={() => edit ? save() : setEdit(true)} className="px-4 py-2 border border-slate-200 text-slate-600 font-bold text-xs rounded-xl">{edit ? "Save Changes" : "Edit Profile"}</button>
              </div>

              {edit ? (
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Full Name</label>
                    <input value={form.displayName} onChange={e => setForm({...form, displayName: e.target.value})} className="w-full px-3.5 py-2 border rounded-lg text-sm bg-slate-50"/>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Bio</label>
                    <textarea value={form.bio} onChange={e => setForm({...form, bio: e.target.value})} rows={3} className="w-full px-3.5 py-2 border rounded-lg text-sm bg-slate-50 resize-none"/>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div>
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Primary Skills</span>
                    <div className="flex flex-wrap gap-1.5">
                      {(form.skills || []).map(sk => <span key={sk} className="px-3 py-1 bg-blue-50 text-blue-700 font-bold rounded-lg text-xs border border-blue-100">{sk}</span>)}
                    </div>
                  </div>
                  {form.secondarySkills && form.secondarySkills.length > 0 && (
                    <div>
                      <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Secondary Skills</span>
                      <div className="flex flex-wrap gap-1.5">
                        {form.secondarySkills.map(sk => <span key={sk} className="px-3 py-1 bg-slate-100 text-slate-700 font-semibold rounded-lg text-xs">{sk}</span>)}
                      </div>
                    </div>
                  )}
                  {form.learningSkills && form.learningSkills.length > 0 && (
                    <div>
                      <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">Skills To Learn</span>
                      <div className="flex flex-wrap gap-1.5">
                        {form.learningSkills.map(sk => <span key={sk} className="px-3 py-1 bg-emerald-50 text-emerald-700 font-semibold rounded-lg text-xs border border-emerald-100">{sk}</span>)}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Repositories in Profile if GitHub Connected */}
            {githubRepos.length > 0 && (
              <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs">
                <h3 className="font-bold text-slate-900 text-base mb-4">Featured GitHub Repositories 🐙</h3>
                <div className="grid sm:grid-cols-2 gap-3">
                  {githubRepos.slice(0, 4).map(repo => (
                    <a key={repo.id} href={repo.html_url} target="_blank" rel="noopener noreferrer" className="p-3 bg-slate-50 border border-slate-200 rounded-xl hover:border-blue-400 transition-colors block">
                      <h4 className="font-bold text-slate-900 text-xs truncate">{repo.name}</h4>
                      <p className="text-[11px] text-slate-500 truncate mt-0.5">{repo.description}</p>
                      <div className="flex items-center gap-3 mt-2 text-[10px] text-slate-400 font-semibold">
                        <span>⭐ {repo.stargazers_count}</span>
                        <span>🍴 {repo.forks_count}</span>
                        <span className="text-blue-600">{repo.language}</span>
                      </div>
                    </a>
                  ))}
                </div>
              </div>
            )}
          </div>

        </div>
      </div>
    </div>
  );
};

// ─── AI ASSISTANT ─────────────────────────────────────────────
const AIAssistant = ({ user }) => {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([
    { from:"ai", text:"Hi! I'm SkillSync AI 👋 Tell me your project idea and required skills, and I'll suggest the perfect team composition!" }
  ]);
  const [input, setInput] = useState("");
  const endRef = useRef(null);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior:"smooth" }); }, [messages]);

  const send = () => {
    if (!input.trim()) return;
    const txt = input.trim();
    setInput("");
    setMessages(m => [...m, { from:"user", text:txt }]);
    setTimeout(() => {
      setMessages(m => [...m, { from:"ai", text:`Great idea for '${txt}'! I recommend creating a Skill Group requiring: 1) ML/Python Developer 2) React Frontend Engineer 3) UI/UX Designer. Click '+ Create Skill Group' to automatically match candidates!` }]);
    }, 500);
  };

  return (
    <div className="fixed bottom-6 right-6 z-[8000]">
      {open ? (
        <div className="bg-white border border-slate-200 rounded-2xl shadow-2xl w-80 sm:w-96 overflow-hidden flex flex-col h-96 fade-up">
          <div className="bg-blue-600 text-white p-4 flex items-center justify-between">
            <span className="font-extrabold text-sm flex items-center gap-2">🤖 SkillSync AI Team Assistant</span>
            <button onClick={() => setOpen(false)} className="text-lg">×</button>
          </div>
          <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-slate-50">
            {messages.map((m,i) => (
              <div key={i} className={`flex ${m.from === "user" ? "justify-end" : "justify-start"}`}>
                <div className={`max-w-[85%] px-3.5 py-2.5 rounded-xl text-xs leading-relaxed ${m.from === "user" ? "bg-blue-600 text-white" : "bg-white border border-slate-200 text-slate-700 shadow-xs"}`}>
                  {m.text}
                </div>
              </div>
            ))}
            <div ref={endRef} />
          </div>
          <div className="p-3 bg-white border-t border-slate-100 flex gap-2">
            <input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==='Enter'&&send()} placeholder="Ask AI Assistant..." className="flex-1 px-3 py-2 border rounded-xl text-xs bg-slate-50 focus:outline-none"/>
            <button onClick={send} className="px-3.5 py-2 bg-blue-600 text-white font-bold text-xs rounded-xl">Send</button>
          </div>
        </div>
      ) : (
        <button onClick={() => setOpen(true)} className="w-13 h-13 bg-blue-600 hover:bg-blue-700 text-white rounded-full flex items-center justify-center shadow-xl transition-all hover:scale-105">
          🤖
        </button>
      )}
    </div>
  );
};

// ─── MAIN APPLICATION COMPONENT ──────────────────────────────
const App = () => {
  const [user, setUser] = useState(() => safeGetStorage("skillsync_user"));
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [page, setPage] = useState("landing");
  const [authModal, setAuthModal] = useState(null);
  const [toast, setToast] = useState(null);
  const [restoringSession, setRestoringSession] = useState(true);

  // Group State & Invitations
  const [groups, setGroups] = useState(() => safeGetStorage("skillsync_groups") || INITIAL_GROUPS);
  const [users, setUsers] = useState(() => safeGetStorage("skillsync_students") || INITIAL_STUDENTS);
  const [invitations, setInvitations] = useState(() => safeGetStorage("skillsync_invitations") || []);
  const [joinRequests, setJoinRequests] = useState(() => safeGetStorage("skillsync_join_requests") || []);

  const [createGroupModalOpen, setCreateGroupModalOpen] = useState(false);
  const [matchModalGroup, setMatchModalGroup] = useState(null);
  const [selectedCandidate, setSelectedCandidate] = useState(null);

  // Supporting GitHub
  const [githubProfile, setGithubProfile] = useState(() => safeGetStorage("skillsync_github_profile"));
  const [githubRepos, setGithubRepos] = useState(() => safeGetStorage("skillsync_github_repositories") || []);

  const API_BASE = window.SKILLSYNC_API_URL || "http://localhost:5000/api";

  // Session Restore
  useEffect(() => {
    const storedUser = safeGetStorage("skillsync_user");

    if (storedUser) {
      setUser(storedUser);
      if (!storedUser.onboardingCompleted) {
        setShowOnboarding(true);
      } else {
        setPage("dashboard");
      }
    }
    setRestoringSession(false);
  }, []);

  // Unauthenticated Route Guard
  useEffect(() => {
    if (!user && page !== "landing") {
      setPage("landing");
    }
  }, [user, page]);

  const handleAuthSuccess = (authUser) => {
    setAuthModal(null);
    setUser(authUser);
    if (authUser.isNewUser || !authUser.onboardingCompleted) {
      setShowOnboarding(true);
    } else {
      setPage("dashboard");
      setToast("Welcome back! 👋");
    }
  };

  const handleOnboardingComplete = (profileData) => {
    const updatedUser = {
      ...user,
      ...profileData,
      displayName: profileData.displayName || user?.displayName || user?.name || "Student",
      onboardingCompleted: true,
      isNewUser: false
    };

    safeSetStorage("skillsync_user", updatedUser);
    setUser(updatedUser);
    setShowOnboarding(false);
    setPage("dashboard");
    setToast("Skill Profile created! Welcome to SkillSync AI 🎉");
  };

  const handleCreateGroup = (newGroupData) => {
    const newGrp = {
      id: "grp_" + Date.now(),
      ...newGroupData,
      creator: { id: user?.id || "usr_me", name: user?.displayName || user?.name || "Me", college: user?.college || "University" },
      members: [{ id: user?.id || "usr_me", name: user?.displayName || user?.name || "Me", role: "Leader" }],
      createdAt: new Date().toISOString()
    };

    const updatedGroups = [newGrp, ...groups];
    setGroups(updatedGroups);
    safeSetStorage("skillsync_groups", updatedGroups);
    setCreateGroupModalOpen(false);
    setToast(`Skill Group "${newGrp.name}" created successfully!`);

    // Prompt Skill Candidate Matches
    setMatchModalGroup(newGrp);
  };

  const handleInviteUser = (candidateUser, targetGroup) => {
    const grp = targetGroup || groups[0];
    if (!grp) return;

    const newInvite = {
      id: "inv_" + Date.now(),
      group: grp,
      sender: { id: user?.id, name: user?.displayName || "Me", college: user?.college },
      receiver: candidateUser,
      status: "pending",
      createdAt: new Date().toISOString()
    };

    const updated = [newInvite, ...invitations];
    setInvitations(updated);
    safeSetStorage("skillsync_invitations", updated);
    setToast(`Invitation sent to ${candidateUser.name} for "${grp.name}"!`);
  };

  const handleAcceptInvite = (invite) => {
    const updatedInvites = invitations.map(i => i.id === invite.id ? { ...i, status: 'accepted' } : i);
    setInvitations(updatedInvites);
    safeSetStorage("skillsync_invitations", updatedInvites);

    // Add user to group members
    const updatedGroups = groups.map(g => {
      if (g.id === invite.group?.id) {
        const currentMembers = g.members || [];
        if (!currentMembers.some(m => m.name === user?.displayName)) {
          return { ...g, members: [...currentMembers, { id: user?.id || "me", name: user?.displayName || "Me", role: "Collaborator" }] };
        }
      }
      return g;
    });

    setGroups(updatedGroups);
    safeSetStorage("skillsync_groups", updatedGroups);
    setToast(`Joined "${invite.group?.name}"!`);
  };

  const handleDeclineInvite = (inviteId) => {
    const updatedInvites = invitations.map(i => i.id === inviteId ? { ...i, status: 'declined' } : i);
    setInvitations(updatedInvites);
    safeSetStorage("skillsync_invitations", updatedInvites);
    setToast("Invitation declined.");
  };

  const handleJoinGroupRequest = (grp) => {
    const isMember = (grp.members || []).some(m => m.name === user?.displayName);
    if (isMember) {
      setToast("You are already a member of this group.");
      return;
    }

    const newReq = {
      id: "req_" + Date.now(),
      group: grp,
      user: { id: user?.id || "me", name: user?.displayName || "Student" },
      status: "pending",
      message: "Interested in contributing to this skill group.",
      createdAt: new Date().toISOString()
    };

    const updated = [newReq, ...joinRequests];
    setJoinRequests(updated);
    safeSetStorage("skillsync_join_requests", updated);
    setToast(`Requested to join "${grp.name}"!`);
  };

  const handleSignOut = () => {
    localStorage.removeItem("skillsync_token");
    localStorage.removeItem("skillsync_user");
    setUser(null);
    setShowOnboarding(false);
    setPage("landing");
    setToast("Signed out successfully");
  };

  if (restoringSession) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="w-10 h-10 bg-blue-600 rounded-xl mx-auto flex items-center justify-center text-white font-extrabold shadow-sm">S</div>
          <div className="w-5 h-5 border-2 border-blue-100 border-t-blue-600 rounded-full animate-spin mx-auto mt-4" />
          <p className="text-sm text-slate-500 mt-3">Loading SkillSync AI Workspace...</p>
        </div>
      </div>
    );
  }

  if (showOnboarding && user) {
    return (
      <>
        <Navbar page={page} setPage={setPage} user={user} onSignOut={handleSignOut} onSignIn={setAuthModal} />
        <Onboarding user={user} onComplete={handleOnboardingComplete} />
        {toast && <Toast message={toast} onClose={() => setToast(null)} />}
      </>
    );
  }

  const renderPage = () => {
    switch (page) {
      case "landing":
        return <LandingPage onSignIn={setAuthModal} />;
      case "dashboard":
        return (
          <Dashboard
            user={user}
            setPage={setPage}
            groups={groups}
            users={users}
            invitations={invitations}
            onOpenCreateGroupModal={() => setCreateGroupModalOpen(true)}
            onInviteUser={(cand) => handleInviteUser(cand)}
            onAcceptInvite={handleAcceptInvite}
            onDeclineInvite={handleDeclineInvite}
            setMatchModalGroup={setMatchModalGroup}
            setSelectedCandidate={setSelectedCandidate}
          />
        );
      case "discover":
        return (
          <DiscoverPage
            groups={groups}
            users={users}
            user={user}
            onOpenCreateGroupModal={() => setCreateGroupModalOpen(true)}
            onJoinGroup={handleJoinGroupRequest}
            setMatchModalGroup={setMatchModalGroup}
          />
        );
      case "my-groups":
        return (
          <MyGroupsPage
            groups={groups}
            invitations={invitations}
            joinRequests={joinRequests}
            user={user}
            onOpenCreateGroupModal={() => setCreateGroupModalOpen(true)}
            onAcceptInvite={handleAcceptInvite}
            onDeclineInvite={handleDeclineInvite}
            onApproveRequest={(req) => {
              const updatedReqs = joinRequests.filter(r => r.id !== req.id);
              setJoinRequests(updatedReqs);
              safeSetStorage("skillsync_join_requests", updatedReqs);
              setToast("Approved member!");
            }}
            onRejectRequest={(reqId) => {
              const updatedReqs = joinRequests.filter(r => r.id !== reqId);
              setJoinRequests(updatedReqs);
              safeSetStorage("skillsync_join_requests", updatedReqs);
              setToast("Request rejected.");
            }}
          />
        );
      case "teams":
        return (
          <TeamsPage
            groups={groups}
            onOpenCreateGroupModal={() => setCreateGroupModalOpen(true)}
            onJoinGroup={handleJoinGroupRequest}
          />
        );
      case "chat":
        return <ChatPage users={users} />;
      case "swap":
        return <SwapPage />;
      case "profile":
        return (
          <ProfilePage
            user={user}
            setUser={setUser}
            githubProfile={githubProfile}
            setGithubProfile={setGithubProfile}
            githubRepos={githubRepos}
            setGithubRepos={setGithubRepos}
          />
        );
      default:
        return <LandingPage onSignIn={setAuthModal} />;
    }
  };

  return (
    <>
      {toast && <Toast message={toast} onClose={() => setToast(null)} />}
      <Navbar
        page={page}
        setPage={setPage}
        user={user}
        onSignOut={handleSignOut}
        onSignIn={setAuthModal}
        pendingCount={invitations.filter(i => i.status === 'pending').length}
      />

      {renderPage()}

      {/* Create Skill Group Modal */}
      {createGroupModalOpen && (
        <CreateSkillGroupModal
          onClose={() => setCreateGroupModalOpen(false)}
          onCreateGroup={handleCreateGroup}
        />
      )}

      {/* Candidate Profile Details View */}
      {selectedCandidate && (
        <UserProfileModal
          candidateUser={selectedCandidate}
          onClose={() => setSelectedCandidate(null)}
          onInviteUser={(cand) => handleInviteUser(cand)}
          groupRequiredSkills={user?.skills || []}
        />
      )}

      {/* Skill Matching Candidate Popup */}
      {matchModalGroup && (
        <div className="fixed inset-0 z-[9500] flex items-center justify-center p-4" onMouseDown={(e) => { if (e.target === e.currentTarget) setMatchModalGroup(null); }}>
          <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-sm" />
          <div className="relative bg-white rounded-3xl shadow-2xl w-full max-w-lg p-6 sm:p-7 fade-up max-h-[88vh] overflow-y-auto">
            <button onClick={() => setMatchModalGroup(null)} className="absolute top-4 right-4 text-slate-400 font-bold text-sm">✕</button>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xl">⚡</span>
              <h3 className="font-extrabold text-slate-900 text-lg">Skill Matches for "{matchModalGroup.name}"</h3>
            </div>
            <p className="text-xs text-slate-500 mb-4">Required Skills: {matchModalGroup.requiredSkills?.join(", ")}</p>

            <div className="space-y-3">
              {users.map(cand => {
                const match = calculateSkillMatch(matchModalGroup.requiredSkills, cand);
                return (
                  <div key={cand.id} className="p-4 border border-slate-200 rounded-2xl bg-slate-50 flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-bold text-slate-900 text-sm">{cand.name}</span>
                        <span className="px-2 py-0.5 rounded-full text-[11px] font-extrabold bg-blue-100 text-blue-700">{match.matchPercent}% Match</span>
                      </div>
                      <p className="text-xs text-blue-600 font-medium">💡 {match.matchReason}</p>
                      <p className="text-[11px] text-slate-400 mt-1">Skills: {cand.skills?.join(", ")}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setSelectedCandidate(cand)}
                        className="px-2.5 py-1.5 border border-slate-200 text-slate-600 font-bold text-xs rounded-xl hover:bg-white"
                      >
                        Profile
                      </button>
                      <button
                        onClick={() => {
                          handleInviteUser(cand, matchModalGroup);
                          setMatchModalGroup(null);
                        }}
                        className="px-3 py-1.5 bg-blue-600 text-white font-bold text-xs rounded-xl hover:bg-blue-700"
                      >
                        + Invite
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {user && <AIAssistant user={user} />}
      {authModal && <AuthModal mode={authModal} onClose={() => setAuthModal(null)} onSuccess={handleAuthSuccess} />}
    </>
  );
};

const rootEl = document.getElementById("root");
if (rootEl) {
  const root = ReactDOM.createRoot(rootEl);
  root.render(
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  );
}
